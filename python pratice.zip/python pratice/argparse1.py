import argparse

# create user-friendly command-line interfaces ,
# process of parsing command-line arguments and generating help messages for our scripts 
parser= argparse.ArgumentParser(description="description of our program")
parser.add_argument('filename', help='Name of the file to process')
with open('output.txt','x') as asFile:
    
    asFile=parser.add_argument('-o', '--output', help='Output file name', default='output.txt')
    parser.add_argument('--verbose', help='Increase output verbosity', action='store_true')


args =parser.parse_args()
print('Filename:', args.filename)
print('Output:', args.output)
print('Verbose:', args.verbose)
