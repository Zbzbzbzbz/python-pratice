data = [
    {
        'name':'instagram',
        'follower' : 346,
        'description':'social media platform',
        'country':'US'
    },
    {
        'name':'praveen',
        'follower':456,
        'description' : 'programmer',
        'country' :'India'
    },
    {
        'name': 'vikas',
        'follower': 123,
        'description' : "frontend programmer",
        'country':'europe'
    }
]