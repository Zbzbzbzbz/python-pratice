a=5
b=type(a)
print(a)
print(b)
a=6.4
b=type(a)
print(b)

my_income=10000
my_taxes=0.1
mytaxes=my_income*my_taxes
print(mytaxes)
