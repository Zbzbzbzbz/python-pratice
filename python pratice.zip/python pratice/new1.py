import multiprocessing

def square(n,result,index):
    result[index] = n*n
if __name__ =="__main__":
    numbers = [1,2,3,4,5]
    results = multiprocessing.Array('i',len(numbers))
    print(type(len(numbers)))
    processes= []
    for i,num in enumerate(numbers):
        p=multiprocessing.Process(target=square,args=(num,results,i))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
        
    print("results :",results[:])