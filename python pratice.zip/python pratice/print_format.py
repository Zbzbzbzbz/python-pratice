mystring = "my name is praveen son of"
print(mystring+"{r}".format(r=" srinivas"))
print(mystring +f'{" srinivas"}')
myfloat = 12/7
print(myfloat)
print("the result was {r:1.5f}".format(r=myfloat))   #floating format format(value:wigth.3f(3 means decimal numbers))

