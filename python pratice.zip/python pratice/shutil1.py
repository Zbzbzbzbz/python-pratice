import shutil

# base_name= 'logs'
# format='zip'
# root_dir='python prative/logs'

# shutil.make_archive(base_name,format,root_dir)

filename ='logs.zip'
extract_dir= '/python pratice/i/'
shutil.unpack_archive('logs.zip',extract_dir)
