import pandas as pd

df = pd.DataFrame({b'lekd':[1,2,3]})
remanings=dict((col, col.encode('ascii', 'ignore').decode('ascii')) for col in df.columns)
df =df.rename(columns=remanings)
print(df)