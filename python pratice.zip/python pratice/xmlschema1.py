import xmlschema
from logging import logs

schema =xmlschema.XMLSchema('schema.xsd')

if not schema.is_valid('schema.xsd'):
    
            logs.critical("XML Document Failed XSD Validation")

            theseResults  = schema.iter_errors('schema.xsd')
            
            for thisResult in theseResults:
                print(thisResult)
                logs.critical(thisResult)

            raise Exception("Invalid Configuration")
is_valid =schema.is_valid('document.xml')
print("is valid",is_valid)
