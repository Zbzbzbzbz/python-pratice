import heapq

heap= []
data = [5,3,8,1,7]
heapq.heapify(data)

item = heapq.heappop(heap)
