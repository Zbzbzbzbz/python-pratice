def selectionSort(customlist):
    for i in range(len(customlist)):
        min_element = i
        for j in range(i+1,len(customlist)):
            if customlist[min_element] < customlist[j]:
                min_element =j
        customlist[i],customlist[min_element]= customlist[min_element],customlist[i]
    print(customlist)

cList =[3,2,1,5,4,5,3,2]
selectionSort(cList)

                