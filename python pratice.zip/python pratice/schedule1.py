import schedule
import time


def my_task():
    print("my task..")

schedule.every().hour.do(my_task)

schedule.every().day.at("09:00").do(my_task)
