#display art
# generate a random account from the game data
# format the account data into printable format
# ask user for a guess
#check if user is correct
#get follower count of each account
# use if statement to check if user is correct
#score keeping 
#make  the game repeatable.
# making account a position B become the next account at position A
# clear the screen between account.

from art import logo,vs 
from game_data import data
import random
from replit import clear
def format_data(account):
    account_name = account["name"]
    account_follower = account['follower']
    account_desc = account["description"]
    account_country = account["country"]
    return f"{account_name}, a {account_desc},from {account_country}"
def check_answer(guess,a_followers,b_followers):
    if a_followers > b_followers:
        return guess =="a"
    else:
        return guess =="b"
     



print(logo)
score =0
game_should_continue = True
account_B =random.choice(data)
while game_should_continue:
    account_A=account_B
    account_B=random.choice(data)
    if account_A == account_B:
        account_B= random.choice(data)
    print(f"compare A: {format_data(account_A)}.")
    print(vs)
    print(f"compare B : {format_data(account_B)}.")
    guess =input("who has more followers? Type 'A' or 'B' : ").lower()


    a_follower_count =account_A["follower"]
    b_follower_count = account_B["follower"]

    is_correct = check_answer(guess,a_follower_count,b_follower_count)
    clear()
    

    if is_correct:
        
        score+=1
        
        print(f"you are correct current score : {score}")
    else:
        game_should_continue= False
        print(f"sorry that's wrong final score : {score}")










