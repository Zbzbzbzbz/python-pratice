logo = """
higher
lower
"""
vs ="""
vscode
"""