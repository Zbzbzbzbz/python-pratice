import pandas as pd
import numpy as  np


# data = { 'Name' :["praveen","vikas","abhi"],
#          "Age": [23,24,25]}

# df =pd.DataFrame(data)
# #print(df)

# # print(df['Name'])


# #df.to_csv('output.csv',index=False)

# df['gender']=['m','m','m']
# # print(df)
# # # print(df['Age']>23)
# # print(df.describe())

# print(df.groupby('gender')['Age'].mean())

# d= {'col1':[1,2,3,4,],'col2': pd.Series([2,3],index=[0,1])}
# df = pd.DataFrame(data=d,dtype=np.int64,index=[0,1,2,3])
# print(df)

data = pd.DataFrame(np.array([(1,2,3),(4,5,6),(7,8,9)]),columns=['a','b','c'])

print(data)












#df.to_csv('output1.csv',index=False)


