num= [10,12,24]
num1 =[20,34,56]

mult =map(lambda x : x*2,num,num1)
print('\n',list(mult))
print("\n",type(mult))
