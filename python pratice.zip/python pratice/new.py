import multiprocessing
from multiprocessing import freeze_support
from Test1 import my_function

if __name__ == "__main__":
    freeze_support()
    pool = multiprocessing.Pool()
    results = pool.map(my_function, [1,2,3,4,5,6])
    pool.close()
    pool.join()
    print(results)
    

