# my_list =['one','two','three','four']
# my_list.append('five')
# my_list.pop()
# my_list.pop(0)
# print(my_list)
# print(my_list[1])
# print(my_list[1:])
# my_list=[1,6,3,5,2]
# num_list=my_list.sort()
# print(num_list)
# print(type(num_list))
# text ="HELLLO WORLD"
# result= '-'.join(text.split()).lower()

# print(result)
# numbers = [n for n in range(3)]
# print(n)
# x=10
# y=3
# print(x//y)

# result= bool('10') + 2
# print(result)




