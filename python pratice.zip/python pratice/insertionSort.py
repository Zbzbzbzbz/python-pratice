def insertionSort(customlist):
    for i in range(1,len(customlist)):
        
        