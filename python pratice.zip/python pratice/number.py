# import pandas as pd

# sample_data= pd.read_csv("books.csv")
# #print(sample_data.head())
# #print(sample_data.tail())

# columns_to_check = ['Title','Stock']

# duplicate_rows = sample_data[sample_data.duplicated[columns_to_check]]

# print(duplicate_rows)
# print(duplicate_rows.shape)
class MyClass:
    def my_method(self):
        return "Hello, world!"

obj = MyClass()
result = obj.my_method[0]