mystring = "Hello World"

#mystring[3] ='h'

a = mystring[2:]
b = a +'h'
print(b)

a= mystring.upper()
print(a)
a=mystring.lower()
print(a)


