def my_function(x):
    x += 1
    return x
