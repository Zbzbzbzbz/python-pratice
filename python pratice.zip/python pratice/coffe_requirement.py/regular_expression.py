# from  larger string we need to find substring is critical that why we are using regular expression
# finding = text + '@'+"text"+"com"
# built in re 
# allows to create specialized pattern string ang search for match within text
