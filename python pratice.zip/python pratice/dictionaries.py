prices_fruit = {'apple':2.33,'orange':4.66,'banala':1.333}
print(prices_fruit.keys())
print(prices_fruit.values())
print(prices_fruit.items())
# d={'key1':233,'key2':[2,4,2],'key3':{'key4':['praveen','2','23',3,4.5]}}
# print(d['key2'][2])
# print(d['key3']['key4'][0].upper())




d= {'key1':233,'key2':['praveen',2,1.3,True],'key3':{'key4':['praveen','2','23',3,4.5]}}
print(d['key2'][2])

print(d['key3']['key4'][2])
print(type(d['key3']['key4'][2]))
