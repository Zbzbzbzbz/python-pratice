pr =(1,'praveen',4.5)
my_list=[1,2,3]
my_list[2]='praveen'
print(my_list)
