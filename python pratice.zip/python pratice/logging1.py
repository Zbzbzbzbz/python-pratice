import logging
import os

# flexible emitting log messages from python programs
#defined in the sys

logs_dir='logs'
os.makedirs(logs_dir,exist_ok=True)
format ='%(asctime)s - %(levelname)s- %(message)s'

# log_file =os.path.join(logs_dir,'app.log')
# logging.basicConfig(filename=log_file,level=logging.DEBUG,format ='%(asctime)s - %(levelname)s- %(message)s')
# log_file =os.path.join(logs_dir,'app1.log')
# logging.basicConfig(filename=log_file,level=logging.DEBUG,format ='%(asctime)s - %(levelname)s- %(message)s')

# logging.debug('this is a debug message')
# logging.debug('this in app1logs message')

logger1 =logging.getLogger('component1')
logger1.setLevel(logging.DEBUG)
file_handler1= logging.FileHandler(os.path.join(logs_dir,'component1.log'))
file_handler1.setFormatter(logging.Formatter(format))
logger1.addHandler(file_handler1)

logger2 = logging.getLogger('component2')
logger2.setLevel(logging.DEBUG)
file_handler2 = logging.FileHandler(os.path.join(logs_dir, 'component2.log'))
file_handler2.setFormatter(logging.Formatter(format))
logger2.addHandler(file_handler2)

logger1.debug("this isdebug message")
logger2.info("this is info message")
