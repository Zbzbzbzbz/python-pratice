from dateutil import parser
from datetime import datetime
from dateutil.relativedelta import relativedelta
from dateutil import tz
import glob


# dt =parser.parser("2024-03-19T12:00:00")
# print(dt)

# dt =datetime.now() +relativedelta(year=1,month=6)


# print(dt)

dt = datetime.now(tz=tz.gettz('America/New_York'))
print(dt)

gt=glob.glob('*.txt')
print(gt)





