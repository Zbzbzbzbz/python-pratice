import warnings

# Define a custom warning class
class MyCustomWarning(Warning):
    print(warnings)

def divide(x, y):
    if y == 0:
        # Emit a warning when dividing by zero
        warnings.warn("Divide by zero", MyCustomWarning)
    return x / y

# Filter out our custom warning
warnings.filterwarnings("ignore", category=MyCustomWarning)

# Call the divide function
result = divide(10, 0)
print("Result:", result)