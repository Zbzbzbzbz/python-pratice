import concurrent.futures
import time

def task(task_id):
    print(f"task {task_id} started")
    time.sleep(2)
    print(f"task {task_id} completed")


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    
    futures = [executor.submit(task,i) for i in range(6)]
    for future in concurrent.futures.as_completed(futures):
        future.result()

        