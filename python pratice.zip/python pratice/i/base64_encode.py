import base64

# binary_data = b'hello world'

# encoded_data= base64.b64encode(binary_data,pad=False)

# print(encoded_data)

# decoded_data=base64.b64decode(encoded_data)
# print(decoded_data)

text =" Hello world!"

encoded_bytes = base64.b64encode(text.encode('utf-8'))

encoded_text= encoded_bytes.decode('utf-8')
print(encoded_text)


    
