import atexit

def praveen():
    print("doing something")

atexit.register(praveen)
print(type(atexit.register(praveen)))
