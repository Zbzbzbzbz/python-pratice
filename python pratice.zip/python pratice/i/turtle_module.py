from turtle import Turtle,Screen

praveen_the_turtle= Turtle()

for _ in range(4):
    
    praveen_the_turtle.forward(100)
    praveen_the_turtle.left(90)

screen =Screen()
screen.setup(width=600,height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.exitonclick()
