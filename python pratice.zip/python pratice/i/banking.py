class Accout():
    def __init__(self,owner,balance):
        
        self.owner=owner
        self.balance=balance
    def deposit(self,de_amt):
        self.balance +=de_amt
        print(f"added {de_amt} to the balance")
    
    def with_drawn(self,wd_amt):
        if self.balance >= wd_amt:
            self.balance -= wd_amt
            print("withdraw is accpeted")
        else:
            print("insifficient balance")
    def __str__(self):
        return f"owner :{self.owner} \nbalance :{self.balance}"
    
a= Accout('praveen',300)
print(a)
a.deposit(300)
a.with_drawn(100)
print(a)



