myfile = open('myfile.txt')
print(myfile.read())
print(myfile.read())
print(myfile.read())
print(myfile.seek(0))
print(myfile.read())

#myfile = open('myfile1.txt')
print(myfile.read())
with open('myfile.txt',mode='r') as f:
    contents=f.read()
    print(contents)
    print(contents)
with open('myfile.txt',mode='w') as f:
    contents= f.write('nnkjevnfkjnkre')
    print(contents)
with open('myfile.txt',mode='a') as f:
    contects= f.write('\nnlkjnjlqwertrsdffd')
    print(contents)
    

    

