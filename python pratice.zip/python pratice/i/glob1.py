import glob

python_files = glob.glob('*.py')
text_file =glob.glob('?.txt')
print(python_files)
print(text_file)
