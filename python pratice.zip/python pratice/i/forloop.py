mylist = [1,2,3,4,5,6,7,8,9,10]

for num in mylist:
    if num%2==0:
        print(f'even is {num}')
    else:
        print(f'odd is {num}')
    # tuples we can use and dictionaries we can use
    
    
    
  
    
    