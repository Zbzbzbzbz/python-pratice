class Cache:
    _instance = None

    # def __new__(cls):
    #     if cls._instance is None:
    #         cls._instance = super().__new__(cls)
    #         # Simulating cache initialization
    #         cls._instance.cache_data = {}
    #     return cls._instance
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.settings= {"debug":True ,"port":8080}
        return cls._instance
    

# Usage
cache1 = Cache()
cache2 = Cache()

print(cache1.settings)  # Output: {}
print(cache1 is cache2)  # Output: True