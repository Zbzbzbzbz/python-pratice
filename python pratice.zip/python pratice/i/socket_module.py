import socket
# create a Tcp//ip socket
server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

server_addresses =('localhost',12345)
server_socket.bind(server_addresses)


# listen for incoming connection 

server_socket.listen(5)
# max no of queued connections

print("waiting for a connection\n")


while True:
    client_stocket,client_Address =server_socket.accept()
    try:
        print("connnection from",client_Address)
        data =client_stocket.recv(1024)
        if data:
            print("received ",data.decode())
            client_stocket.sendall(data)
        else:
            print("no data")
            break
    finally:
        client_stocket.close()
        

