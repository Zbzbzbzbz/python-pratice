import urllib.request
import urllib.parse
import os,sys

# with urllib.request.urlopen('http://example.com/') as response:
#     html =response.read()
#     print(html)
# url = "http://www.example.com/"
# parsed_url = urllib.parse.urlparse(url)
# print(parsed_url)
# print(type(parsed_url))

query_params = {'name':"praveen",'age':24,'city':'anatapur'}


encoded_params= urllib.parse.urlencode(query_params)
print(encoded_params)
decoded_params = urllib.parse.parse_qs(encoded_params)
print(decoded_params)
with open('cap2.txt','x') as asFile:
    asFile.write("helloworld")
       
    
