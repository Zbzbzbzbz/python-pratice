
my_list= [x*y for x in [2,4,6] for y in [1,10,1000]]

print(my_list)

st = " my name is Sam is to start doing scam"
for word in st.split():
    if(word[0].lower()=='s'):
        print(f'word letter will be {word}')
        
for num in range(0,11):
    if(num%2==0):
        print(num)
my_list= [x for x in range(1,51) if x%3==0]
print(my_list)

st ="To facilitate the import of ServiceNow CMDB data into BigFix, a Master Operator account is required. Otherwise, the minimum account requirements to send BigFix endpoint data to ServiceNow are the following:"
for word in st.split():
    if len(word)%2==0:
        print(word+'this is even')
    else:
        print(word+'this is odd')

for num in range(1,101):
    if num%3==0 and num %5 ==0:
        print('fizzbuzz')
    elif num%3==0:
        print('fizz')
    elif num%5==0:
        print('buzz')
        
st ="To facilitate the import of ServiceNow CMDB data into BigFix, a Master Operator account is required. Otherwise, the minimum account requirements to send BigFix endpoint data to ServiceNow are the following:"
mylist= [word[0] for word in st.split()]
print(mylist)

pra =[('abhi',100),('praveen',200),('vikas',300)]

def empolyee_check(pra):
    current_max_hours=0
    employee_of_month =''
    for employee,hours in pra:
        if hours > current_max_hours:
            current_max_hours = hours
            employee_of_month = employee
        else:
            pass
    return (employee_of_month,current_max_hours)
name,hours = empolyee_check(pra)
print(name)
print(hours)




    
    



    
        

        
    
    

