from typing import Optional,Union

# def vikas(name :Optional[str])->str:
#     if name is not None:
#         return f"Hello {name}"
#     else:
#         return "Hello World"
# print(vikas("Abhijith")) 
# print(vikas(None))

# def find_index(lst:list,value:int)->Optional[int]:
    
#     try:
#         return lst.index(value)
#     except ValueError as e:
#         return e
    
# result = find_index([1, 2, 3, 4, 5], 3)
# print(result)  # Output: 2

# result = find_index([1, 2, 3, 4, 5], 6)
# print(result)

# person: dict[str,Optional[str]] ={
#     'name':"alice",
#     "age" :"None",
#     "city":"Anantapur"
# }
# print(person['name'])
# print(person['age'])
# print(person['city'])

def process_data(data : Union[str,int,None])->None:
    if isinstance(data,int):
        print(f"string data : {data}")
    elif isinstance(data,int):
        print(f"integer data : {data}")
    else:
        print(None)

process_data("Hello")  # Output: Processing string data: Hello
process_data(42)       # Output: Processing integer data: 42
process_data(None)    
        
        
    



        
