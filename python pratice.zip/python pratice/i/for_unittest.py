import unittest
import cap

class TestCap(unittest.TestCase):
    # def test_one_word(self):
    #     text = 'python'
    #     result =  cap.cap_text(text)
    #     self.assertEqual(result,'Python')
    def test_triple_words(self):
        text="python praveen vikas"
        result = cap.cap_text(text)
        self.assertEqual(result,"Python Praveen Vikas")
        
    
    def test_multiple_words(self):
        text ='python praveen'
        result =cap.cap_text(text)
        self.assertEqual(result,'Python Praveen')
        print("Success1")

if __name__ == '__main__':
    unittest.main()
    
        
        