class Singleton:
    _instance =None
    @staticmethod
    def get_instance():
         
         
        if Singleton._instance is None:
            
            Singleton._instance = Singleton()
        return Singleton._instance
obj=Singleton.get_instance()
obj1=Singleton.get_instance()
print(obj is obj1)
