'''def myfunc(*args,**kwargs):
    print(type(args))
    print(type(kwargs))
    print('i would like {} {}'.format(args[0],kwargs['food']))
result = myfunc(10,20,30,fruit='orange',food ='eggs')
print(result)

def myfunc(*args):
    return sum(args)
myfunc(10,20,30,40)



def lesser_of_two_evens(a,b):
    if a%2==0 and b%2==0:
        if(a < b):
            result = a
        else:
            result = b
    else:
        if a > b:
            result =a
        else:
            result = b
    return result

result1 =lesser_of_two_evens(5,4) we can use min(a,b) and max(a,b)

print(result1)

def checking_two_strings_first_letter_should_same(text):
    wordlist = text.split()
    first=wordlist[0]
    second= wordlist[1]
    return first[0]==second[0]
result=checking_two_strings_first_letter_should_same('laveen love')
print(result)


def given_integers(a,b):
    return  (a+b)==20 or a==20 or b==20

result= given_integers(10,30)
print(result)'''

def first_four_letter_uppercase(name):
    first_letter=name[0]
    inbetween =name[1:3]
    four_leter=name[3]
    rest =name[4:]
    return first_letter.upper() + inbetween + four_leter.upper() +rest
result = first_four_letter_uppercase("praveen")# we can use capitalize() 
print(result)

def reverse_string(name):
    wordlist = name.split()
    reverse_wordlist= wordlist[::-1]
    return reverse_wordlist
reverse_string('iam home')

def almost_there(n):
    return (abs(100-n) <=10) or (abs(200-n) <= 10)
almost_there(209)

def has_33(nums):
    for i in range(0,len(nums)-1):
        if nums[i] ==3 and nums[i+1] ==3:
            return True
    return False
def paper_doll(text):
    result= ''
    for char in text:
        result += char*3
    return result


def summer_69(arr):
    total =0
    add= True
    for num in arr:
        while add:
            if num!=6:
                total +=num
                break
            else:
                add= False
        while not add:
            if num!=9:
                break
            else:
                add= True
                break
    return total

def square(num):
    return num**2
my_nums = [1,2,3,4,5]
for item in map(square,my_nums):
    print(item)
    
    


   


    


    

    





    