import requests
import lxml
import bs4


'''
res = requests.get("https://en.wikipedia.org/wiki/Deep_Blue_(chess_computer)")
soup = bs4.BeautifulSoup(res.text,'lxml')
soup.select('img')
type(print(soup.select('.thumbimage')))


f =open('my_computer_image.jpg','wb')
f.write(.color_content(78945))
f.close()

authors =set()

url ='https://en.wikipedia.org/wiki/Deep_Blue_(chess_computer)'
for page in range(1,10):
    page_url = url+str(page)
    res = requests.get(page_url)
    soup =bs4.BeautifulSoup(res.text,'lxml')
    for name in soup.select('.authors'):
        authors.add(name.text)'''
from PIL import Image

win =Image.open('myname.jpg')
type(win)
print(type(win))
print(win)
win.filename
win.format_description
win.crop(0,0,100,100)
win.size
x=0
y=0
w=1950/3
h=1300/10
hex(342)
2**4
pow(2,4,3)
round(3)
round(4.9)
round(3.22342,2)

s= 'hello world'
s.capitalize()
s.upper()
s.lower()
s.count('o')
s.find('o')
s.center(20,'z')
s.isalpha()
s.isalnum()
s.islower()
s.isspace()
s.istitle()
s.startswith('o')
s.split()
s.partition()# only one instance
s= set()
s.add(1)
s.add(2)
#no duplicates
s
s.clear()
s ={1,2,3,}

sc =s.copy()
s.add(4)
s.difference(sc)
s.difference_update(sc)
s1 = {1,4,2,3}
s2 ={1,2,3,3}
s1.difference(s2)
s.discard(12)
s1.intersection(s2)

s1.isdisjoint(s2)
s1.issubset(s2)
s1.issuperset(s2)
    
 
d= {'k':3,"l":4}
{k:v**2 for k,v in zip(['a','b'],range(10))}   
x=[1,2,3]

x.append([4,5])
print(x)
x.extend([4,5])
print(x)
x.index(2)
x.insert(2,'inserted')
x.pop()# default last elements
x.pop(3)
x.remove('insertd')
l =[1,2,3,4,3]
l.remove(3) # removing  the first instance of list
l.reverse()
l.sort()
import smtplib

smtp_object = smtplib.SMTP('smtp.gmail.com',587)
smtp_object.ehlo()
smtp_object.starttls()
import getpass
password =getpass.getpass('password please')

email =getpass.getpass("email: ")
password = getpass.getpass("password")
smtp_object.login(email,password)

from_address  =email
to_address = email
subject = input("enter the subject line")
message = input("enter the body message: ")
smtp_object.sendmail(from_address,to_address,message)
 
 
 
import imaplib


M = imaplib.IMAP4_SSL('impa.gmail.com')
email =getpass.getpass("email: ")
password = getpass.getpass("password")

M.login(email,password)
M.list()


 