nums =[2,7,12,24]
target= 19
def twosum(nums: list[int],target:int)-> list[int]:
    num_indics={}
    for i,num in enumerate(nums):
        complement =target-num
        if complement in  num_indics:
            return [num_indics[complement],i]
        num_indics[num] =i
    return []


print(twosum(nums,target))

        