import numpy as np
from array import *
''' 
my_array = array.array('i')
print(my_array)

my_array1 = array.array('i',[1,1,2,3,4])
print(my_array1)

np_array = np.array([],dtype=int)
print(np_array)
np_array1 = np.array([1,2,3,4,56,4])
print(np_array1)
##########
#inserting the array
my_array1.insert(2,6)
print(my_array1)
my_array1.pop(3)
print(my_array1)
def tranverseArray(array):
    for i in array:
        print(i)
tranverseArray(arr1)
'''
arr1 =array.array('i', [1,2,3,4,5,6])



def accessArray(array,index):
    if index >len(array):
        print(" there is no element in a array")
    else:
        print(array[index])
accessArray(arr1,2)
