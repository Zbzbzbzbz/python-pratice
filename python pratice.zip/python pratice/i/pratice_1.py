"""
year = int(input("what is your year of brith?\n"))
if(year>1980 and year < 1994):
    print("you are in a millenial")
elif year >1994:
    print("you are  a Gen Z.")
    """

