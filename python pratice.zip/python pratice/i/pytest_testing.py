import pytest

def test_print_statement(capfd):
    result = 10**2
    
    assert result in 100
    