import platform

print("os :",platform.system())
print("processor architecture",platform.machine())
print("Python Version:", platform.python_version()) 
print(" complete data :")
