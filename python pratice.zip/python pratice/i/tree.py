class TreeNode:
    def __init__(self,data,children = []):
        self.data=data
        self.children = children
    def __str__(self,level =0):
        ret =  " " *level + str(self.data) + "\n"
        for child in self.children:
            ret += child.__str__(level+1)
        return ret
    def addchild(self,TreeNode):
        self.children.append(TreeNode)
tree = TreeNode('Drinks',[])
Cold = TreeNode('Cold',[])
hot = TreeNode('hot',[])
tree.addchild(Cold)
tree.addchild(hot)
juice = TreeNode('juice',[])
beer = TreeNode('beer',[])
coffee = TreeNode('coffee',[])
badam_milk = TreeNode('badam_milk',[])
Cold.addchild(juice)
Cold.addchild(beer)
hot.addchild(coffee)
hot.addchild(badam_milk)
print(tree)
