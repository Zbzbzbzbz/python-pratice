"""
def f(x, *y,z=0):
    return x,y,z
print(f(1,2,3,4,0))


a= [[],"abc",[0],1,0]
print(list(filter(bool,a)))
a = [1,2,3]
b =a
b[0] =a
print(a)

i=20
for i in range(4,8):
    pass
print(i)

e= enumerate(['a','b'],5)
for i,c in e:
    print(i,c,end=" ")
 
from student import Student

import pickle


with open('student.pickle','rb') as f:
    obj= pickle.load(f)
obj.display()
a=[1,2,3]
b=a[:]
a.append(4)
print(b)
print(a)
    

x ={3,3,3,3,3}
y=len(x)^2
print(f"output : {y}")




print(*4* 'jo',sep='--')

x= [0,1,2,3]
y=x
x += [4,5]
print(y)

list1 =[' ',
        'frvhjjvjhfrjejvkjv',
        'bfreniufh3piurhfurnpeufqirgf']
print(max(list1))

list1 =[104,
        'mohan',
        111.5,
        "mcm"]
print(max(list1))

def a():
    return 4,5,6,7
p,q,r,s =a()
print(p,q,r,s)

from time import sleep
from tqdm import tqdm
for i in  tqdm(range(10000)):
    sleep(0.0005)

    

def func(x):
    return x*3
result =func("hello")
print(result)

a= [1,2,3]
for x in a:
    print(x + 1 ,end=" ")
    
     
def func(num):
    return num + 13
func(13)
print(num)


print(True and not True or False and not False)
import calendar


yy=2024
mm=12
dd=19
print(calendar.month(yy,mm,dd))

s1= "Hello"
s2 = ""
for i in s1:
    s2 += chr(ord(i)+3)
print(s2)

a=5
b=10
a,b=b,a
print(a)
print(b)



l=list("1234")
l[0] =l[1] =5
print(l)


a={}
a[5.5] ="ruby"
a[5.52] ="java"
a[5] ="python"
print(a)


dict ={1:2,3:4}
for i,j in dict.items():
    print(i,j,sep=":")

a,b=12,34
b,c=21,22
print(a+b+c)
"""

# a= [1,2,3]
# b=[3,4,5,6]
# print(a<b)

# list1 =[12,1,3,4]
# list1.extend(6)




# print(list1)

# str1 ="hello=== world"
# result =str1.split('===')
# # print(result)
# def func(a=1,b=2,c=3):
#     return a*b*c
# result = func(5,c=4)
# print(result)

# item =['Apple','orange','pineapple']
# print("SlNo  fruits Name")
# for index ,value in enumerate(item,3):
#     print(index,value,sep='\t')

# t=2
# def func():
#     global t
#     t=4
#     print(t)
# func()

from io import StringIO
import pandas as pd
df = pd.DataFrame([['a', 'b'], ['c', 'd']],
                  index=['row 1', 'row 2'],
                  columns=['col 1', 'col 2'])
print(df)


    



