from random import shuffle

def shuffle_list(mylist):
    shuffle(mylist)
    return mylist


mylist=['','O','']
result= shuffle_list(mylist)
print(result)

def player_guess():
    guess =''
    while guess not in ['0','1','2']:
        guess = input("pick a number: 0,1 or 2")
    return int(guess)

myindex = player_guess()

print(myindex)

def check_guess(mylist,guess):
    if mylist[guess] == 'O':
        print("correct!")
    else:
        print("wrong guess")
        print(mylist)
        
mylist =['','O','']
 
mixed_list =shuffle_list(mylist)

guess =player_guess() 

check_guess(mixed_list,guess)
     
    




