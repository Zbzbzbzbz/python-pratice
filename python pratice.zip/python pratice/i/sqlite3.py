import sqlite3

# self-contained, serverless,zero-configuration databases small-scale db operations
con =sqlite3.connect('example.db')
con.execute('''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER
            )''')
con.execute('''INSERT INTO users (name, age) VALUES (?, ?)''', ('Alice', 30))
con.execute('''INSERT INTO users (name, age) VALUES (?, ?)''', ('Bob', 25))

# Commit the transaction
con.commit()

cursor =con.execute(''' SELECT id,name,age FROM users''')
for row in cursor:
    print(row)

con.close()
