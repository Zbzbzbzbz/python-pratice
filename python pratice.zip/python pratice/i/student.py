class Student:
    def __init__(self, name:str,age:int,gender:str)-> None:
        self.name= name
        self.age=age
        self.gender =gender
    def display(self) -> None:
        print(f"nameis = {self.name}")
        print(f"age is = {self.age}")
        print(f"gender is = {self.gender}")
        
        