def cap_text(text):
    '''
    Input string
    output the capatalized string
    
    '''
    return text.title()

    
