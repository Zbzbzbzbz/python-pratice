# def new_docorator(original_func):
#     def wrap_func():
#         print("something different")
#         original_func()
#         print("printing same")
#     return wrap_func

# @new_docorator
# def func_needs_decorator():
#     print("this will do")
    
# print(func_needs_decorator())

def new_decorator(original_func):
    
    def wrap_func():
        
        
        print("something different")        
        original_func()
        print("printing same")
    return wrap_func

@new_decorator
def func_needs_decorator():
    print("this will do")

print(func_needs_decorator())



  