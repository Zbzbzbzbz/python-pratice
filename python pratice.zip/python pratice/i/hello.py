def hello():
    return "hello!"

#print(hello())

greet =hello
#print(greet())
del hello
print(greet())