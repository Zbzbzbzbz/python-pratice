
constents = ['a','e','f','q','m','n','v','r']
vowels =['a','e','i','o','u']

custom_filters = lambda item : False if item in vowels else True
constent= filter(custom_filters,constents)

print("\n",list(constent))
print(type(constent))

