def bubbleSort(customList):
    for i in range(len(customList)-1):
        for j in range(len(customList)-i-1):
            if customList[j]>customList[j+1]:
                customList[j],customList[j+1] = customList[j+1],customList[j]
    print(customList)
    print(type(customList))
    

cList = [4,1,3,2,9,8,5]
print(bubbleSort(cList))

# time complexcity : o(n)^2
#space complexity :o(1)


            