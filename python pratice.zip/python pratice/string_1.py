a = " i'am doing work"
print(a)
print(len(a))
mystring = "abcdefghijklmno"
print(mystring[2])
print(mystring[6])
print(mystring[14])
#print(mystring[17])
print(mystring[2:])
print(mystring[:13])
print(mystring[:12])
print(mystring[1:13])
print(mystring[4:14])
print(mystring[1:14:2])
print(mystring[1:14:3])
print(mystring[1:14:4])
print(mystring[1:14:5])
print(mystring[1:14:7])
print(mystring[1:17])
print(mystring[::7])




