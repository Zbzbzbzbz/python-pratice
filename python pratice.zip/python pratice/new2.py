import multiprocessing
import time
from multiprocessing import freeze_support

def producer(queue):
    for i in range(5):
        print("producing",i)
        queue.put(i)
        time.sleep(1)
def consumer(queue):
    while True:
        item =queue.get()
        print("consuming :",item)
        time.sleep(2)
if __name__ == "__main__":
    freeze_support()
    queue = multiprocessing.Queue()
    
    p= multiprocessing.Process(target=producer,args=(queue,))
    c=multiprocessing.Process(target=consumer,args=(queue,))
    p.start()
    c.start()
    
    p.join()
    c.join()
    print(f"producer :{p} consumer :{c}")
        